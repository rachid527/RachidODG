from django.shortcuts import render, redirect, get_object_or_404
from .models import Projet, Tache
from .forms import ProjetForm, TacheForm
from django.contrib.auth.decorators import login_required

# Liste des projets
@login_required
def liste_projets(request):
    projets = Projet.objects.filter(proprietaire=request.user)
    return render(request, 'projets/liste_projets.html', {'projets': projets})

# Créer un projet
@login_required
def creer_projet(request):
    if request.method == 'POST':
        form = ProjetForm(request.POST)
        if form.is_valid():
            projet = form.save(commit=False)
            projet.proprietaire = request.user
            projet.save()
            return redirect('liste_projets')
    else:
        form = ProjetForm()
    return render(request, 'projets/creer_projet.html', {'form': form})

# Modifier un projet
@login_required
def modifier_projet(request, projet_id):
    projet = get_object_or_404(Projet, id=projet_id, proprietaire=request.user)
    if request.method == 'POST':
        form = ProjetForm(request.POST, instance=projet)
        if form.is_valid():
            form.save()
            return redirect('liste_projets')
    else:
        form = ProjetForm(instance=projet)
    return render(request, 'projets/modifier_projet.html', {'form': form})

# Supprimer un projet
@login_required
def supprimer_projet(request, projet_id):
    projet = get_object_or_404(Projet, id=projet_id, proprietaire=request.user)
    projet.delete()
    return redirect('liste_projets')

# Ajouter une tâche à un projet
@login_required
def ajouter_tache(request, projet_id):
    projet = get_object_or_404(Projet, id=projet_id, proprietaire=request.user)
    if request.method == 'POST':
        form = TacheForm(request.POST)
        if form.is_valid():
            tache = form.save(commit=False)
            tache.projet = projet
            tache.save()
            return redirect('liste_projets')
    else:
        form = TacheForm()
    return render(request, "projets/ajouter_tache.html", {"form": form, "projet": projet})
