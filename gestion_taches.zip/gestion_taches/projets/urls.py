from django.urls import path
from . import views

app_name = 'projets'  # Permet d'utiliser `{% url 'projets:liste_projets' %}` dans les templates

urlpatterns = [
    path('', views.liste_projets, name='liste_projets'),
    path('creer/', views.creer_projet, name='creer_projet'),
    path('modifier/<int:projet_id>/', views.modifier_projet, name='modifier_projet'),
    path('supprimer/<int:projet_id>/', views.supprimer_projet, name='supprimer_projet'),
    path('<int:projet_id>/ajouter_tache/', views.ajouter_tache, name='ajouter_tache'),
]
