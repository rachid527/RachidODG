from django.db import models

from django.contrib.auth.models import User

# Modèle Projet
class Projet(models.Model):
    nom = models.CharField(max_length=255)
    description = models.TextField()
    date_creation = models.DateTimeField(auto_now_add=True)
    proprietaire = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.nom

# Modèle Tâche
class Tache(models.Model):
    projet = models.ForeignKey(Projet, related_name='taches', on_delete=models.CASCADE)
    titre = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    est_terminee = models.BooleanField(default=False)
    date_echeance = models.DateField()

    def __str__(self):
        return self.titre
