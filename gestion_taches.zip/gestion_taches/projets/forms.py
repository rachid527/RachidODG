from django import forms
from .models import Projet, Tache

# Formulaire Projet
class ProjetForm(forms.ModelForm):
    class Meta:
        model = Projet
        fields = ['nom', 'description']

# Formulaire Tâche
class TacheForm(forms.ModelForm):
    class Meta:
        model = Tache
        fields = ['titre', 'description', 'date_echeance', 'est_terminee']
