from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required

# Vue pour l'inscription
def inscription(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f"Compte créé pour {username} ! Connecte-toi maintenant.")
            return redirect('connexion')
    else:
        form = UserCreationForm()
    return render(request, 'utilisateurs/inscription.html', {'form': form})

# Vue pour afficher le profil utilisateur
@login_required
def profil(request):
    return render(request, 'utilisateurs/profil.html')
def connexion_view(request):
    return render(request, 'utilisateurs/connexion.html') 